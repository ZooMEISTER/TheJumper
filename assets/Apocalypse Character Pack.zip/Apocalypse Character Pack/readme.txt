This asset pack contains :

6 different animations for an apocalyse survivor in 4 directions (in png format):
Idle animation : Idle.png (3 x 4 cells)
Walk/Run animation : Walk.png (5 x 4 cells)
Shoot animation : Shoot.png (5 x 4 cells)
Stab animation : Stab.png (5 x 4 cells)
Shooting Crossbow animation : Crossbow.png (7 x 4 cells)
Death animation : Death.png (5 x 4 cells)

2 animations for bullets and arrows in 4 directions (in png format):
Bullet animation : Bullet.png (5 x 4 cells)
Arrow animation : Arrow.png (9 x 4 cells)

4 different animations for a Zombie in 4 directions (in png format):
Idle animation: Idle.png (6 x 4 cells)
Walk/Run animation : Walk.png (11 x 4 cells)
Attack animation : Attack.png (9 x 4 cells)
Death animation : (8 x 4 cells)

*The sprites are 32x32
 

Licensing Information:

This asset pack is available for both commercial and non-commercial use. Modifications are allowed but redistribution or resale of
the asset pack is prohibited even if modified. Credit is not required but appreciated.


Contact Information:

If you have any questions or issues with the asset pack, please leave a comment at https://cuddle-bug.itch.io/apocalyse or send a message @cuddleebug on twitter or instagram!
https://twitter.com/cuddleebug/
https://instagram.com/cuddleebug/

 
